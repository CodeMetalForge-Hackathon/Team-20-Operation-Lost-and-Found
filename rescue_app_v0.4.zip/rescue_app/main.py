#!/usr/bin/env python3
"""
main.py — the rescue medical check app.

    python3 main.py             run on the Pi with the PiTFT
    python3 main.py --preview   no hardware: save every page as a PNG in ./preview

Answers are saved in ./reports/ (one file per session, plus latest.json).
After the last question it shows REPORT COLLECTED, counts down, and closes.
"""

import math
import sys
import time
from pathlib import Path

from content import QUESTIONS
from events import TAP, ButtonEvent
from layout import Layout
from pages import BACK, NEXT, CompletePage, QuestionPage
from report import MedicalReport
from version import VERSION

APP_FOLDER = Path(__file__).resolve().parent      # works no matter where it's started from
REPORTS_FOLDER = APP_FOLDER / "reports"
SECONDS_BETWEEN_CHECKS = 0.02


def build_pages():
    page_count = len(QUESTIONS) + 1
    question_pages = [QuestionPage(index, page_count) for index in range(len(QUESTIONS))]
    return question_pages + [CompletePage(page_count)]


class RescueApp:
    """
    Owns the pages and the loop: read buttons -> current page decides -> redraw.
    The loop ends by itself when the last page's countdown runs out.
    """

    def __init__(self, screen, buttons, layout, report):
        self.screen = screen
        self.buttons = buttons
        self.layout = layout
        self.report = report
        self.pages = build_pages()
        self.page_index = 0
        self.entered_page_at = time.monotonic()

    def current_page(self):
        return self.pages[self.page_index]

    def apply(self, action):
        last_page = len(self.pages) - 1
        previous_index = self.page_index
        if action == NEXT:
            self.page_index = min(self.page_index + 1, last_page)
        elif action == BACK:
            self.page_index = max(self.page_index - 1, 0)
        if self.page_index != previous_index:
            self.entered_page_at = time.monotonic()     # restart the countdown clock on every page change

    def redraw(self):
        self.screen.show(self.current_page().render(self.layout, self.report))

    def countdown_seconds_left(self):
        """Seconds until close if on the last page, else None."""
        page = self.current_page()
        if not isinstance(page, CompletePage):
            return None
        elapsed = time.monotonic() - self.entered_page_at
        return max(0, math.ceil(page.CLOSE_AFTER_SECONDS - elapsed))

    def run(self):
        self.redraw()
        keep_running = True
        try:
            while keep_running:
                for event in self.buttons.poll():
                    self.apply(self.current_page().handle(event, self.report))
                    self.redraw()

                seconds_left = self.countdown_seconds_left()
                if seconds_left is not None:
                    page = self.current_page()
                    if seconds_left != page.seconds_left:      # redraw once per second, not every loop
                        page.seconds_left = seconds_left
                        self.redraw()
                    if seconds_left == 0:
                        self.report.mark_collected()
                        keep_running = False

                time.sleep(SECONDS_BETWEEN_CHECKS)
        except KeyboardInterrupt:
            keep_running = False


def run_on_pi():
    print(f"Rescue app {VERSION}")
    import lgpio
    from hardware import ButtonPanel, DisplayProfile, Screen

    profile = DisplayProfile()
    gpio_chip = lgpio.gpiochip_open(0)
    screen = Screen(profile, gpio_chip)
    buttons = ButtonPanel(profile, gpio_chip)
    app = RescueApp(screen, buttons, Layout(profile.width, profile.height), MedicalReport(REPORTS_FOLDER))
    try:
        app.run()
    finally:
        from PIL import Image
        screen.show(Image.new("RGB", (profile.width, profile.height), (0, 0, 0)))
        screen.close()
        buttons.close()
        lgpio.gpiochip_close(gpio_chip)


def run_preview():
    """Render every page to PNG, after simulating a few taps, without any hardware."""
    preview_folder = APP_FOLDER / "preview"
    preview_folder.mkdir(exist_ok=True)
    layout = Layout(320, 240)
    report = MedicalReport(APP_FOLDER / "preview_reports")
    pages = build_pages()
    simulated_taps = [0, 1, 1, 0, 2, 1, 0]    # mostly bad answers, to stress the summary page
    for page_index, page in enumerate(pages):
        page.render(layout, report).save(preview_folder / f"page_{page_index + 1}.png")
        if page_index < len(simulated_taps):
            page.handle(ButtonEvent(simulated_taps[page_index], TAP), report)
    pages[0].render(layout, report).save(preview_folder / "page_1_answered.png")
    print("values saved:", report.values)
    print("needs attention:", report.needs_attention())
    print(f"{VERSION}: pages written to {preview_folder}")


if __name__ == "__main__":
    if "--preview" in sys.argv:
        run_preview()
    else:
        run_on_pi()
