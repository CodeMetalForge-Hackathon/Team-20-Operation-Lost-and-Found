# Rescue app — iteration log

Newest first. The version is also saved inside every medical report and shown on the summary page,
so any report can be traced to the exact code that produced it.

## v0.2
- Questions reordered, most life-threatening first: blood loss, breathing, head wound, cold,
  walking, arms, safe to move (7 questions).
- New icons: breathing (lungs), cold (thermometer + snowflake), safe to move (lying person + warning).
- Food / water question removed (icon kept in icons.py).
- Summary page spaces items to fit all 7.
- Iteration numbers added: version.py, CHANGELOG.md, version in report JSON and on summary page.

## v0.1
- First OOD build: hardware, layout, icons, content, pages, report, main.
- 5 questions (walk, blood loss, arms, food / water, head), 320x240 landscape, buttons 17/22/23/27.
- Tap = answer, hold button 1 = back, hold 2/3 = skip, hold 4 on summary = new report.
- Saves values list + needs_attention to reports/ (session file + latest.json).
